
import DASHATDashboardPreview from './DASHATDashboardPreview';

export default function App() {
  return <DASHATDashboardPreview />;
}
